Use ECommerceCustomerAnalytics;
--CHECK ROW COUNTS AFTER IMPORT

select count(*) as rows_2009_2010 from dbo.[Year 2009-2010];
select count(*) as rows_2010_2011 from dbo.[Year 2010-2011];
