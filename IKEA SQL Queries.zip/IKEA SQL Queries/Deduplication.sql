Use EcommerceCustomerAnalytics;
-- CHECK 1- MISSING CUSTOMER ID
select count(*) as Missing_CustomerID
from dbo.RetailCombined where Customer_ID is null;
-- CHECK 2- NEGATIVE OR ZERO QUANTITY
select count(*) as Negative_Qty
from dbo.RetailCombined where Quantity<=0;
--CHECK 3- MISSING DESCRIPTION
select count(*) as MissingDescription
from dbo.RetailCombined
where Description is null;
--CHECK 4- EXACT DUPLICATE ROWS
select Invoice, StockCode, Description, Quantity, InvoiceDate, Price, Customer_ID, Country,
count(*) as ExactDupeCount
from dbo.RetailCombined
group by Invoice, StockCode, Description, Quantity, InvoiceDate, Price, Customer_ID, Country
having count(*)>1;
WITH DuplicateCTE AS (
    SELECT 
        ROW_NUMBER() OVER (
            PARTITION BY Invoice, StockCode, Description, Quantity, InvoiceDate, Price, Customer_ID, Country
            ORDER BY (SELECT NULL)
        ) AS RowNum
    FROM dbo.RetailCombined 
)
SELECT COUNT(*) AS TotalDuplicateRows
FROM DuplicateCTE
WHERE RowNum > 1;