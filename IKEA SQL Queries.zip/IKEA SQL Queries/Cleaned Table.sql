Use EcommerceCustomerAnalytics;
--DEDUPLICATE AND PRODUCE THE FINAL CLEANED TABLE
WITH deduped as(
select *,
row_number() over(
partition by Invoice, StockCode, Description, Quantity, InvoiceDate, Price, Customer_ID, Country
order by (select null)
) as RouNun
from dbo.RetailCombined
)
select Invoice, StockCode, Description, Quantity, InvoiceDate, Price, Customer_ID, Country, SourceSheet
into dbo.RetailCleaned
from deduped
where RouNun=1;