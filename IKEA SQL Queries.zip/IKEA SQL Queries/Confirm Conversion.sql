Use EcommerceCustomerAnalytics;

-- CONFIRM THE CONVERSION WORKED CLEANLY
select count(*) as total_rows from dbo.RetailCombined;
select count(*) as failed_dates from dbo.RetailCombined where InvoiceDate is null;
select count(*) as failed_prices from dbo.RetailCombined where price is null;
